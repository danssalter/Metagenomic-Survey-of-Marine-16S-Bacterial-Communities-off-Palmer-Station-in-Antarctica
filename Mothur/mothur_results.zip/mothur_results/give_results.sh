#!/bin/bash

# This script loops through all <SAMPLE_DATE> folders and collects result files
# and copies them to a new folder

# Define the source and destination directories
source_dir="/Users/dsalter/Documents/Antarctica_Project/mothur/mothur_results"
destination_dir="/Users/dsalter/Documents/Antarctica_Project/mothur/result_counts"

# Create the destination directory if it doesn't exist
mkdir -p "$destination_dir"

# Loop through each folder in the source directory
for folder in "$source_dir"/*/; do
    # Check if the file "final.opti_mcc.0.03.cons.taxonomy" exists in the current folder
    if [ -e "$folder/final.opti_mcc.0.03.cons.taxonomy" ]; then
        # Get the folder name and remove any trailing slashes
        folder_name=$(basename "${folder%/}")
        
        # Create a unique filename that includes the folder name
        unique_filename="${folder_name}_count.taxonomy"
        
        # Copy the file to the destination directory with the unique name
        cp "$folder/final.opti_mcc.0.03.cons.taxonomy" "$destination_dir/$unique_filename"
        echo "Copied 'final.opti_mcc.0.03.cons.taxonomy' from $folder to $destination_dir as $unique_filename"
    else
        echo "'final.opti_mcc.0.03.cons.taxonomy' not found in $folder"
    fi
done

echo "Script completed"